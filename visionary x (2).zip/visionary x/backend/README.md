# AI4Agri Backend (FastAPI + MongoDB)

This folder contains the FastAPI backend for AI4Agri with MongoDB for persistence.

## Features

- Health check: `GET /health`
- Contact messages: `POST /api/contact`
- Feedback: `POST /api/feedback`
- CORS open for local development

## Requirements

- Python 3.10+
- MongoDB running locally or in the cloud (e.g., MongoDB Atlas)

## Setup

1. Create environment file

   Copy the example env and adjust values as needed.

   ```bash
   cp .env.example .env
   ```

   Update `MONGODB_URI` and `MONGODB_DB` in `.env`.

2. Create and activate a virtual environment (recommended)

   ```bash
   python -m venv .venv
   .venv\Scripts\activate  # Windows PowerShell
   # source .venv/bin/activate  # macOS/Linux
   ```

3. Install dependencies

   ```bash
   pip install -r requirements.txt
   ```

4. Run the server

   From the project root (`visionary x/`), run:

   ```bash
   uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
   ```

   The API will be available at: http://127.0.0.1:8000

5. Test endpoints

   - Health: http://127.0.0.1:8000/health
   - Docs (Swagger): http://127.0.0.1:8000/docs

## Frontend integration

The frontend uses `app.js` and will POST to the backend by default at `http://127.0.0.1:8000`.
You can override the base URL by setting either of the following in the browser console:

```js
localStorage.setItem('ai4agri_api', 'https://your-api-host');
// or
window.BACKEND_URL = 'https://your-api-host';
```

### Contact form

`POST /api/contact`

Body:
```json
{
  "name": "Your Name",
  "email": "you@example.com",
  "message": "Hello!"
}
```

### Feedback form

`POST /api/feedback`

Body:
```json
{
  "message": "Your feedback here",
  "rating": 5,
  "areas": ["Support", "Accuracy"]
}
```

## Notes

- CORS is configured to allow all origins for local development. Tighten this for production.
- The backend uses `motor` (async Mongo driver) and `python-dotenv` for reading `.env`.
