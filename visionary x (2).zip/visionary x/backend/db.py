import os
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from typing import Optional
from dotenv import load_dotenv

_client: Optional[AsyncIOMotorClient] = None
_db: Optional[AsyncIOMotorDatabase] = None


def _get_env(name: str, default: Optional[str] = None) -> str:
    val = os.getenv(name, default)
    if val is None:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return val


async def connect_to_mongo() -> None:
    global _client, _db
    try:
        # Load .env once on startup (safe if called multiple times)
        load_dotenv()
        mongo_uri = _get_env("MONGODB_URI", "mongodb://127.0.0.1:27017")
        mongo_db = _get_env("MONGODB_DB", "ai4agri")

        print(f"Connecting to MongoDB at: {mongo_uri}")
        _client = AsyncIOMotorClient(mongo_uri)
        _db = _client[mongo_db]
        
        # Test the connection
        await _client.admin.command('ping')
        print(f"Successfully connected to MongoDB database: {mongo_db}")
        
    except Exception as e:
        print(f"Failed to connect to MongoDB: {e}")
        print("The application will continue running, but database operations will fail.")
        print("Please ensure MongoDB is running and the connection details are correct.")
        # Don't raise the exception - let the app start even if DB is unavailable


async def close_mongo_connection() -> None:
    global _client
    if _client is not None:
        _client.close()
        _client = None


def get_db() -> AsyncIOMotorDatabase:
    if _db is None:
        raise RuntimeError("Database not initialized. Ensure connect_to_mongo() ran on startup.")
    return _db
