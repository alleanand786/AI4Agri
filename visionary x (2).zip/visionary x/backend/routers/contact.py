from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr, Field
from datetime import datetime
from db import get_db

router = APIRouter()

class ContactIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    email: EmailStr
    message: str = Field(..., min_length=1, max_length=5000)

class ContactOut(BaseModel):
    id: str
    name: str
    email: EmailStr
    message: str
    created_at: datetime

@router.post("/contact", response_model=ContactOut)
async def create_contact(payload: ContactIn):
    db = get_db()
    doc = {
        "name": payload.name,
        "email": payload.email,
        "message": payload.message,
        "created_at": datetime.utcnow(),
    }
    res = await db.contacts.insert_one(doc)
    if not res.inserted_id:
        raise HTTPException(status_code=500, detail="Failed to save contact message")
    return ContactOut(
        id=str(res.inserted_id),
        name=doc["name"],
        email=doc["email"],
        message=doc["message"],
        created_at=doc["created_at"],
    )
