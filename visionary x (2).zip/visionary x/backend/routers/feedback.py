from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from datetime import datetime
from db import get_db

router = APIRouter()

class FeedbackIn(BaseModel):
    message: str = Field(..., min_length=1, max_length=5000)
    rating: int | None = Field(None, ge=1, le=5)
    areas: list[str] | None = None

class FeedbackOut(BaseModel):
    id: str
    message: str
    rating: int | None = None
    areas: list[str] | None = None
    created_at: datetime

@router.post("/feedback", response_model=FeedbackOut)
async def create_feedback(payload: FeedbackIn):
    db = get_db()
    doc = {
        "message": payload.message,
        "rating": payload.rating,
        "areas": payload.areas,
        "created_at": datetime.utcnow(),
    }
    res = await db.feedback.insert_one(doc)
    if not res.inserted_id:
        raise HTTPException(status_code=500, detail="Failed to save feedback")
    return FeedbackOut(
        id=str(res.inserted_id),
        message=doc["message"],
        rating=doc.get("rating"),
        areas=doc.get("areas"),
        created_at=doc["created_at"],
    )
