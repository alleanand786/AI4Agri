from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import feedback, contact
from db import connect_to_mongo, close_mongo_connection

app = FastAPI(title="AI4Agri Backend", version="0.1.0")

# CORS - allow local dev frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # relax for local dev; tighten in production
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    await connect_to_mongo()

@app.on_event("shutdown")
async def shutdown_event():
    await close_mongo_connection()

@app.get("/")
async def root():
    return {
        "message": "Welcome to AI4Agri Backend API",
        "version": "0.1.0",
        "docs": "/docs",
        "health": "/health"
    }

@app.get("/health")
async def health():
    return {"status": "ok"}

@app.get("/health/db")
async def health_db():
    """Check database connection health"""
    try:
        from db import _client, _db
        if _client is None:
            return {"status": "error", "message": "Database client not initialized"}
        
        # Test database connection
        await _client.admin.command('ping')
        
        # Get database info
        db_name = _db.name if _db is not None else "Unknown"
        server_info = await _client.server_info()
        
        return {
            "status": "ok", 
            "message": "Database connection healthy",
            "database": db_name,
            "mongodb_version": server_info.get("version", "Unknown"),
            "connection_uri": "mongodb://localhost:27017/"
        }
    except Exception as e:
        return {
            "status": "error", 
            "message": f"Database connection failed: {str(e)}",
            "expected_uri": "mongodb://localhost:27017/",
            "expected_database": "AI4Agri"
        }

# Mount routers
app.include_router(feedback.router, prefix="/api", tags=["feedback"]) 
app.include_router(contact.router, prefix="/api", tags=["contact"]) 
