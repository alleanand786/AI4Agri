// AI4Agri landing interactions
(function () {
  const ready = (fn) => {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  };

  // Public hook to allow the host app to set custom behavior
  // Usage: window.onGetStarted(() => { /* navigate */ })
  let getStartedHandler = null;
  window.onGetStarted = function (cb) {
    if (typeof cb === 'function') getStartedHandler = cb;
  };

  function showLanguageScreen() {
    const landing = document.getElementById('screen-landing');
    const bottomGraphic = document.querySelector('.bottom-graphic');
    const language = document.getElementById('screen-language');
    if (landing) landing.classList.add('hidden');
    if (bottomGraphic) bottomGraphic.classList.add('hidden');
    if (language) language.classList.remove('hidden');
  }

  function showLocationScreen() {
    const language = document.getElementById('screen-language');
    const locationScreen = document.getElementById('screen-location');
    language?.classList.add('hidden');
    locationScreen?.classList.remove('hidden');
  }

  // Simple i18n scaffolding (strings can be expanded later)
  const i18n = {
    en: {
      choose_location: 'Choose your Location!!',
      fetching_location: 'Fetching your location…',
    },
  };

  function setLanguage(lang) {
    try {
      localStorage.setItem('ai4agri_lang', lang);
    } catch {}
    document.documentElement.lang = lang || 'en';
    const dict = i18n[lang] || i18n.en;
    const title = document.querySelector('#screen-location .location-title');
    const fetching = document.getElementById('location-name');
    if (title) title.textContent = dict.choose_location;
    if (fetching) fetching.textContent = dict.fetching_location;
  }

  function initFromStoredLanguage() {
    let lang = 'en';
    try {
      lang = localStorage.getItem('ai4agri_lang') || 'en';
    } catch {}
    setLanguage(lang);
  }

  // Geolocation + reverse geocoding (Nominatim) + static map
  async function fetchReverseGeocode(lat, lon) {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}`;
    const res = await fetch(url, {
      headers: {
        'Accept': 'application/json',
      },
    });
    if (!res.ok) throw new Error('Reverse geocode failed');
    return res.json();
  }

  function buildStaticMap(lat, lon) {
    // OpenStreetMap static map service (no API key). Marker in green.
    const marker = `${lat},${lon},lightgreen1`;
    const params = new URLSearchParams({
      center: `${lat},${lon}`,
      zoom: '15',
      size: '340x255',
      markers: marker,
    });
    return `https://staticmap.openstreetmap.de/staticmap.php?${params.toString()}`;
  }

  function startGeolocation() {
    const nameEl = document.getElementById('location-name');
    const mapEl = document.getElementById('static-map');
    const liveMap = document.getElementById('map');
    if (!navigator.geolocation) {
      if (nameEl) nameEl.textContent = 'Location not supported on this device.';
      return;
    }
    if (nameEl) nameEl.textContent = 'Fetching your location…';
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude: lat, longitude: lon } = pos.coords;
      // Show static map
      if (mapEl) mapEl.src = buildStaticMap(lat, lon);
      // Initialize interactive map if Leaflet is available
      if (typeof L !== 'undefined' && liveMap) {
        ensureLeafletMap(liveMap, lat, lon, pos.coords.accuracy || 50);
      }
      try {
        const data = await fetchReverseGeocode(lat, lon);
        const display = formatPlaceName(data);
        if (nameEl) nameEl.textContent = display;
      } catch (e) {
        if (nameEl) nameEl.textContent = 'Unable to get place name.';
      }
    }, (err) => {
      if (nameEl) {
        if (err.code === err.PERMISSION_DENIED) {
          nameEl.textContent = 'Permission denied. Enable location to continue.';
        } else {
          nameEl.textContent = 'Could not fetch your location.';
        }
      }
    }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 });
  }

  let leafletInstance = null;
  function ensureLeafletMap(container, lat, lon, accuracy) {
    // Show the live map, hide static image under it
    container.classList.add('active');
    const img = document.getElementById('static-map');
    if (img) img.style.visibility = 'hidden';

    // Create map if not created, otherwise just update view
    if (!leafletInstance) {
      leafletInstance = L.map(container, { zoomControl: true, attributionControl: true });
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors',
      }).addTo(leafletInstance);
    }

    leafletInstance.setView([lat, lon], 17);

    // Clear previous layers except the base tile layer
    leafletInstance.eachLayer((layer) => {
      // Keep the tile layer only
      if (layer instanceof L.TileLayer) return;
      leafletInstance.removeLayer(layer);
    });

    const marker = L.circleMarker([lat, lon], {
      radius: 8,
      color: '#4F8F2C',
      weight: 3,
      fillColor: '#4F8F2C',
      fillOpacity: 0.9,
    }).bindTooltip('You are here', { permanent: false, direction: 'top' });
    marker.addTo(leafletInstance);

    if (accuracy && accuracy > 0) {
      const circle = L.circle([lat, lon], { radius: accuracy, color: '#4F8F2C', fillColor: '#4F8F2C', fillOpacity: 0.15 });
      circle.addTo(leafletInstance);
    }
  }

  function formatPlaceName(nominatimJson) {
    // Try to compose something like: Locality, District, State
    const a = nominatimJson.address || {};
    const city = a.city || a.town || a.village || a.hamlet || '';
    const county = a.county || a.district || '';
    const state = a.state || a.region || '';
    const parts = [city, county, state].filter(Boolean);
    return parts.join(', ');
  }

  ready(() => {
    const btn = document.getElementById('get-started');
    const btnBack = document.getElementById('btn-back');
    const btnNext = document.getElementById('btn-lang-next');
    const btnLocBack = document.getElementById('btn-loc-back');
    const btnLocNext = document.getElementById('btn-loc-next');
    const options = Array.from(document.querySelectorAll('.lang-option'));
    let selected = (document.querySelector('.lang-option.selected')?.dataset.value) || 'en';

    initFromStoredLanguage();

    if (btn) {
      btn.addEventListener('click', () => {
        // Visual micro-interaction
        btn.style.transform = 'translateY(1px) scale(0.992)';
        setTimeout(() => (btn.style.transform = ''), 90);

        // If a custom handler is registered, call it
        if (typeof getStartedHandler === 'function') {
          try {
            getStartedHandler();
          } catch (err) {
            console.error('Error in getStarted handler:', err);
          }
        }

        // Show language screen
        showLanguageScreen();
      });
    }

    // Back button returns to landing
    btnBack?.addEventListener('click', () => {
      document.getElementById('screen-language')?.classList.add('hidden');
      document.getElementById('screen-landing')?.classList.remove('hidden');
      document.querySelector('.bottom-graphic')?.classList.remove('hidden');
    });

    // Selection logic
    options.forEach((el) => {
      el.addEventListener('click', () => {
        options.forEach((o) => o.classList.remove('selected'));
        el.classList.add('selected');
        selected = el.dataset.value;
      });
    });

    // Language Next button -> store language, update lang attribute, go to location screen
    btnNext?.addEventListener('click', () => {
      try { localStorage.setItem('ai4agri_lang', selected); } catch {}
      setLanguage(selected);
      const evt = new CustomEvent('ai4agri:language-selected', { detail: { lang: selected } });
      window.dispatchEvent(evt);
      showLocationScreen();
      startGeolocation();
    });

    // Location back -> return to language screen
    btnLocBack?.addEventListener('click', () => {
      document.getElementById('screen-location')?.classList.add('hidden');
      document.getElementById('screen-language')?.classList.remove('hidden');
    });

    // Location next -> emit event with current location text
    btnLocNext?.addEventListener('click', () => {
      const name = document.getElementById('location-name')?.textContent || '';
      const evt = new CustomEvent('ai4agri:location-confirmed', { detail: { place: name } });
      window.dispatchEvent(evt);
      try { localStorage.setItem('ai4agri_place', name); } catch {}
      // Go to auth choice screen
      document.getElementById('screen-location')?.classList.add('hidden');
      document.getElementById('screen-auth')?.classList.remove('hidden');
    });

    // Market screen wiring
    function showMarket(){
      document.getElementById('screen-dashboard')?.classList.add('hidden');
      document.getElementById('screen-market')?.classList.remove('hidden');
    }
    // From dashboard bottom tab bar (4th tab)
    document.querySelector('#screen-dashboard .tabbar .tab:nth-child(4)')?.addEventListener('click', showMarket);
    // From Quick Actions: 2nd button is Market Prices
    (function(){
      const qs = document.querySelectorAll('#screen-dashboard .quick-grid .quick');
      if (qs && qs.length >= 2) qs[1].addEventListener('click', showMarket);
    })();
    document.getElementById('btn-market-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-market')?.classList.add('hidden');
      document.getElementById('screen-dashboard')?.classList.remove('hidden');
    });
    // Simple client-side search filter
    document.getElementById('btn-mkt-search')?.addEventListener('click', ()=>{
      const q = (document.getElementById('mkt-search')?.value||'').toLowerCase();
      const items = document.querySelectorAll('#mkt-grid .mkt-item');
      items.forEach(li=>{
        const name = li.getAttribute('data-name')?.toLowerCase() || '';
        li.style.display = !q || name.includes(q) ? '' : 'none';
      });
    });

    // Market detail navigation from grid
    document.querySelectorAll('#mkt-grid .mkt-item').forEach(li=>{
      li.addEventListener('click', ()=>{
        // Prefill crop
        const name = li.getAttribute('data-name') || '';
        const select = document.getElementById('md-crop');
        if (select){
          Array.from(select.options).forEach(opt=>{ opt.selected = (opt.textContent === name); });
        }
        document.getElementById('screen-market')?.classList.add('hidden');
        document.getElementById('screen-market-detail')?.classList.remove('hidden');
      });
    });
    document.getElementById('btn-mktdet-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-market-detail')?.classList.add('hidden');
      document.getElementById('screen-market')?.classList.remove('hidden');
    });

    // Advisory screen wiring
    function showAdvisory(){
      document.getElementById('screen-dashboard')?.classList.add('hidden');
      document.getElementById('screen-advisory')?.classList.remove('hidden');
    }
    // From dashboard bottom tab bar (2nd tab)
    document.querySelector('#screen-dashboard .tabbar .tab:nth-child(2)')?.addEventListener('click', showAdvisory);
    // From Quick Actions: 3rd button is Crop Advisory
    (function(){
      const qs = document.querySelectorAll('#screen-dashboard .quick-grid .quick');
      if (qs && qs.length >= 3) qs[2].addEventListener('click', showAdvisory);
    })();
    // Back from advisory
    document.getElementById('btn-adv-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-advisory')?.classList.add('hidden');
      document.getElementById('screen-dashboard')?.classList.remove('hidden');
    });

    // Assistant wiring
    document.querySelector('#screen-dashboard .mic-fab')?.addEventListener('click', ()=>{
      document.getElementById('screen-dashboard')?.classList.add('hidden');
      document.getElementById('screen-assistant')?.classList.remove('hidden');
    });
    document.getElementById('btn-assist-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-assistant')?.classList.add('hidden');
      document.getElementById('screen-dashboard')?.classList.remove('hidden');
    });
    document.getElementById('assist-send')?.addEventListener('click', ()=>{
      const input = document.getElementById('assist-input');
      const text = input?.value.trim();
      if (!text) return;
      const card = document.querySelector('#screen-assistant .chat-card');
      const row = document.createElement('div');
      row.className = 'chat-row';
      row.innerHTML = `<div class="bot-ic">🧑‍🌾</div><div class="bubble" style="background:#fff;color:#1b1b1b;border-color:#ddd">${text}</div>`;
      card.appendChild(row);
      input.value = '';
      // simple demo reply
      setTimeout(()=>{
        const r = document.createElement('div');
        r.className = 'chat-row';
        r.innerHTML = `<div class="bot-ic">🤖</div><div class="bubble">Thanks! For demo purposes, features are limited offline.</div>`;
        card.appendChild(r);
        card.scrollTop = card.scrollHeight;
      }, 600);
      card.scrollTop = card.scrollHeight;
    });

    // Photo upload
    const fileInput = document.getElementById('assist-file');
    document.getElementById('assist-photo')?.addEventListener('click', ()=> fileInput?.click());
    fileInput?.addEventListener('change', ()=>{
      const file = fileInput.files?.[0];
      if (!file) return;
      const url = URL.createObjectURL(file);
      const card = document.querySelector('#screen-assistant .chat-card');
      const row = document.createElement('div');
      row.className = 'chat-row';
      row.innerHTML = `<div class="bot-ic">🧑‍🌾</div><div class="bubble" style="background:#fff;color:#1b1b1b;border-color:#ddd"><img src="${url}" alt="upload" style="max-width:100%; border-radius:8px;"/></div>`;
      card.appendChild(row);
      card.scrollTop = card.scrollHeight;
    });

    // Mic mock transcription
    document.getElementById('assist-mic')?.addEventListener('click', ()=>{
      const input = document.getElementById('assist-input');
      input.value = 'What should I plant next month?';
      toast('Mic (demo): transcribed sample question');
    });

    // Share chat
    document.getElementById('assist-share')?.addEventListener('click', async ()=>{
      const card = document.querySelector('#screen-assistant .chat-card');
      const text = Array.from(card.querySelectorAll('.bubble')).map(b=> b.textContent.trim()).join('\n\n');
      try {
        await navigator.clipboard.writeText(text);
        toast('Chat copied to clipboard');
      } catch {
        // Fallback: download txt
        const blob = new Blob([text], {type: 'text/plain'});
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'AI4AgriAssistant_Chat.txt';
        a.click();
      }
    });

    // =============================
    // Settings wiring
    // =============================
    function showSettings(){
      document.getElementById('screen-dashboard')?.classList.add('hidden');
      document.getElementById('screen-settings')?.classList.remove('hidden');
      // Initialize toggles from storage
      try {
        const prefs = JSON.parse(localStorage.getItem('ai4agri_settings')||'{}');
        ['tg-email','tg-push','tg-weather','tg-2fa','tg-sync'].forEach(id=>{
          const el = document.getElementById(id);
          if (el && typeof prefs[id] === 'boolean') el.checked = prefs[id];
        });
      } catch {}
      // Update storage label
      const rng = document.getElementById('set-storage');
      const lbl = document.getElementById('set-storage-label');
      if (rng && lbl) lbl.textContent = `${rng.value}% used`;
    }
    // From dashboard bottom tab bar (5th tab)
    document.querySelector('#screen-dashboard .tabbar .tab:nth-child(5)')?.addEventListener('click', showSettings);
    // Back
    document.getElementById('btn-set-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-settings')?.classList.add('hidden');
      document.getElementById('screen-dashboard')?.classList.remove('hidden');
    });
    // Persist toggles
    const toggleIds = ['tg-email','tg-push','tg-weather','tg-2fa','tg-sync'];
    toggleIds.forEach(id=>{
      document.getElementById(id)?.addEventListener('change', ()=>{
        let prefs = {};
        try { prefs = JSON.parse(localStorage.getItem('ai4agri_settings')||'{}'); } catch {}
        const el = document.getElementById(id);
        prefs[id] = !!el?.checked;
        try { localStorage.setItem('ai4agri_settings', JSON.stringify(prefs)); } catch {}
      });
    });
    // Storage label live update
    document.getElementById('set-storage')?.addEventListener('input', (e)=>{
      const lbl = document.getElementById('set-storage-label');
      if (lbl) lbl.textContent = `${e.target.value}% used`;
    });
    // Logout demo
    document.getElementById('btn-logout')?.addEventListener('click', ()=>{
      try {
        localStorage.removeItem('ai4agri_user');
      } catch {}
      toast('Logged out');
      // Return to Auth choice
      document.getElementById('screen-settings')?.classList.add('hidden');
      document.getElementById('screen-dashboard')?.classList.add('hidden');
      document.getElementById('screen-auth')?.classList.remove('hidden');
    });

    // Connect With Us & Feedback navigation
    function openConnect(){
      document.getElementById('screen-settings')?.classList.add('hidden');
      document.getElementById('screen-connect')?.classList.remove('hidden');
    }
    function openFeedback(){
      document.getElementById('screen-settings')?.classList.add('hidden');
      document.getElementById('screen-feedback')?.classList.remove('hidden');
    }
    document.getElementById('btn-connect')?.addEventListener('click', openConnect);
    document.getElementById('btn-feedback')?.addEventListener('click', openFeedback);
    document.getElementById('btn-connect-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-connect')?.classList.add('hidden');
      document.getElementById('screen-settings')?.classList.remove('hidden');
    });
    document.getElementById('btn-feedback-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-feedback')?.classList.add('hidden');
      document.getElementById('screen-settings')?.classList.remove('hidden');
    });
    // Connect form submit demo
    document.getElementById('btn-cn-send')?.addEventListener('click', ()=>{
      toast('Thanks for contacting us! We will get back soon.');
    });
    // Feedback submit demo
    document.getElementById('btn-fb-submit')?.addEventListener('click', ()=>{
      toast('Feedback submitted. Thank you!');
    });

    // =============================
    // Global bottom navbar router
    // =============================
    function hideAllScreens(){
      document.querySelectorAll('section[id^="screen-"]').forEach(s=> s.classList.add('hidden'));
    }
    function setActiveTab(tab){
      document.querySelectorAll('.tabbar .tab').forEach(btn=>{
        const v = btn.getAttribute('data-tab');
        btn.classList.toggle('active', v === tab);
      });
    }
    function navigate(tab){
      hideAllScreens();
      setActiveTab(tab);
      switch (tab) {
        case 'advisory':
          // run any init and ensure screen is shown
          try { showAdvisory?.(); } catch {}
          document.getElementById('screen-advisory')?.classList.remove('hidden');
          break;
        case 'detection':
          try { showDetection?.(); } catch {}
          document.getElementById('screen-detection')?.classList.remove('hidden');
          break;
        case 'market':
          try { showMarket?.(); } catch {}
          document.getElementById('screen-market')?.classList.remove('hidden');
          break;
        case 'settings':
          try { showSettings?.(); } catch {}
          document.getElementById('screen-settings')?.classList.remove('hidden');
          break;
        case 'home':
        default:
          document.getElementById('screen-dashboard')?.classList.remove('hidden');
      }
    }
    // Attach to all tabbars that declare data-tab
    document.querySelectorAll('.tabbar .tab[data-tab]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const tab = btn.getAttribute('data-tab');
        if (!tab) return;
        navigate(tab);
      });
    });
  });
})();

// =============================
// Auth flow additions
// =============================
(function(){
  const ready = (fn) => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn();
  };

  function showSignup(){
    document.getElementById('screen-auth')?.classList.add('hidden');
    document.getElementById('screen-login')?.classList.add('hidden');
    document.getElementById('screen-signup')?.classList.remove('hidden');
  }
  function showLogin(){
    document.getElementById('screen-auth')?.classList.add('hidden');
    document.getElementById('screen-signup')?.classList.add('hidden');
    document.getElementById('screen-login')?.classList.remove('hidden');
  }
  function showDashboard(){
    ['screen-landing','screen-language','screen-location','screen-auth','screen-signup','screen-login'].forEach(id=>{
      document.getElementById(id)?.classList.add('hidden');
    });
    const dash = document.getElementById('screen-dashboard');
    dash?.classList.remove('hidden');
    // Personalize name
    try {
      const email = localStorage.getItem('ai4agri_user') || '';
      const nameFromEmail = email.split('@')[0];
      const pretty = nameFromEmail ? nameFromEmail.replace(/\./g,' ').replace(/_/g,' ') : 'Farmer';
      const el = document.getElementById('farmer-name');
      if (el && pretty) el.textContent = pretty + ' ji';
    } catch {}
    // Activate Home tab
    document.querySelectorAll('.tabbar .tab').forEach((t,i)=> t.classList.toggle('active', i===0));
  }

  function toast(msg){
    let t = document.querySelector('.toast');
    if (!t){ t = document.createElement('div'); t.className='toast'; document.body.appendChild(t); }
    t.textContent = msg; t.classList.add('show');
    setTimeout(()=> t.classList.remove('show'), 1600);
  }

  ready(()=>{
    // Auth choice
    document.getElementById('btn-auth-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-auth')?.classList.add('hidden');
      document.getElementById('screen-location')?.classList.remove('hidden');
    });
    document.getElementById('btn-auth-email')?.addEventListener('click', showSignup);
    document.getElementById('btn-auth-get-started')?.addEventListener('click', showSignup);
    document.getElementById('btn-auth-guest')?.addEventListener('click', showDashboard);

    // Mock Google popup
    const openGoogle = ()=> document.getElementById('google-modal')?.classList.remove('hidden');
    const closeGoogle = ()=> document.getElementById('google-modal')?.classList.add('hidden');
    document.getElementById('btn-auth-google')?.addEventListener('click', openGoogle);
    document.getElementById('btn-login-google')?.addEventListener('click', openGoogle);
    document.getElementById('google-cancel')?.addEventListener('click', closeGoogle);
    document.querySelectorAll('.acct').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const email = btn.getAttribute('data-email');
        try { localStorage.setItem('ai4agri_user', email); } catch{}
        closeGoogle();
        toast('Signed in successfully');
        setTimeout(showDashboard, 900);
      });
    });

    // Signup
    document.getElementById('btn-signup-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-signup')?.classList.add('hidden');
      document.getElementById('screen-auth')?.classList.remove('hidden');
    });
    document.getElementById('link-to-login')?.addEventListener('click', (e)=>{ e.preventDefault(); showLogin(); });
    const suEmail = document.getElementById('su-email');
    const suPass = document.getElementById('su-pass');
    const suPass2 = document.getElementById('su-pass2');
    const suContinue = document.getElementById('btn-su-continue');
    const updateSuBtn = ()=>{
      const ok = suEmail?.value.includes('@') && suPass?.value.length>=6 && suPass?.value===suPass2?.value;
      suContinue.disabled = !ok; suContinue.classList.toggle('enabled', !!ok);
    };
    [suEmail, suPass, suPass2].forEach(el=> el?.addEventListener('input', updateSuBtn));
    suContinue?.addEventListener('click', ()=>{
      try { localStorage.setItem('ai4agri_user', suEmail.value); } catch{}
      toast('Successfully signed up');
      setTimeout(showDashboard, 900);
    });

    // Login
    document.getElementById('btn-login-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-login')?.classList.add('hidden');
      document.getElementById('screen-auth')?.classList.remove('hidden');
    });
    document.getElementById('link-to-signup')?.addEventListener('click', (e)=>{ e.preventDefault(); showSignup(); });
    const liEmail = document.getElementById('li-email');
    const liPass = document.getElementById('li-pass');
    const liContinue = document.getElementById('btn-li-continue');
    const updateLiBtn = ()=>{
      const ok = liEmail?.value.includes('@') && (liPass?.value?.length||0) >= 6;
      liContinue.disabled = !ok; liContinue.classList.toggle('enabled', !!ok);
    };
    [liEmail, liPass].forEach(el=> el?.addEventListener('input', updateLiBtn));
    liContinue?.addEventListener('click', ()=>{
      try { localStorage.setItem('ai4agri_user', liEmail.value); } catch{}
      toast('Successfully logged in');
      setTimeout(showDashboard, 900);
    });

    // Profile navigation
    const profileBtn = document.querySelector('#screen-dashboard .icon-btn[aria-label="Profile"]');
    profileBtn?.addEventListener('click', ()=>{
      // Personalize profile screen
      try {
        const email = localStorage.getItem('ai4agri_user') || 'gsingh@gmail.com';
        const nameFromEmail = email.split('@')[0];
        const pretty = nameFromEmail ? nameFromEmail.replace(/\./g,' ').replace(/_/g,' ') : 'Gurpreet Singh';
        const nameEls = document.querySelectorAll('#screen-profile .p-name, #screen-profile #farmer-name');
        nameEls.forEach(el=> el.textContent = pretty.replace(/\b\w/g, c=> c.toUpperCase()));
        const emailRow = Array.from(document.querySelectorAll('#screen-profile .p-row span'))
          .find(span => span.textContent.trim().toLowerCase() === 'email');
        if (emailRow) {
          const strong = emailRow.parentElement.querySelector('strong');
          if (strong) strong.textContent = email;
        }
      } catch {}
      document.getElementById('screen-dashboard')?.classList.add('hidden');
      document.getElementById('screen-profile')?.classList.remove('hidden');
    });

    document.getElementById('btn-prof-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-profile')?.classList.add('hidden');
      document.getElementById('screen-dashboard')?.classList.remove('hidden');
    });

    // Edit Profile navigation
    const editBtn = document.querySelector('#screen-profile .p-edit');
    editBtn?.addEventListener('click', ()=>{
      // Prefill fields from stored profile
      let profile = {};
      try { profile = JSON.parse(localStorage.getItem('ai4agri_profile')||'{}'); } catch {}
      // Fallbacks from current profile screen content
      const fallbackName = document.querySelector('#screen-profile .p-name')?.textContent?.trim() || '';
      const rows = Array.from(document.querySelectorAll('#screen-profile .p-card:first-of-type .p-row'));
      const fallbackEmail = (rows[1]?.querySelector('strong')?.textContent || '').trim();
      const fallbackPhone = (rows[2]?.querySelector('strong')?.textContent || '').trim();

      document.getElementById('pf-name').value = profile.name || fallbackName || '';
      document.getElementById('pf-email').value = profile.email || fallbackEmail || '';
      document.getElementById('pf-phone').value = profile.phone || fallbackPhone || '';
      document.getElementById('pf-address').value = profile.address || 'Doddaballapur';
      document.getElementById('pf-acres').value = profile.acres || 10;
      document.getElementById('pf-acres-cult').value = profile.acresCult || 5;
      document.getElementById('pf-crops').value = profile.crops || 'Rice';
      document.getElementById('pf-exp').value = profile.exp || 10;

      document.getElementById('screen-profile')?.classList.add('hidden');
      document.getElementById('screen-profile-edit')?.classList.remove('hidden');
    });

    // Back from profile edit
    document.getElementById('btn-profe-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-profile-edit')?.classList.add('hidden');
      document.getElementById('screen-profile')?.classList.remove('hidden');
    });

    // Save profile
    document.getElementById('btn-pf-save')?.addEventListener('click', ()=>{
      const profile = {
        name: document.getElementById('pf-name').value.trim(),
        email: document.getElementById('pf-email').value.trim(),
        phone: document.getElementById('pf-phone').value.trim(),
        address: document.getElementById('pf-address').value.trim(),
        acres: document.getElementById('pf-acres').value.trim(),
        acresCult: document.getElementById('pf-acres-cult').value.trim(),
        crops: document.getElementById('pf-crops').value.trim(),
        exp: document.getElementById('pf-exp').value.trim(),
      };
      try { localStorage.setItem('ai4agri_profile', JSON.stringify(profile)); } catch {}

      // Reflect on profile screen
      const setRow = (label, value)=>{
        const row = Array.from(document.querySelectorAll('#screen-profile .p-card'))
          .flatMap(card=> Array.from(card.querySelectorAll('.p-row')))
          .find(r=> r.querySelector('span')?.textContent.trim().toLowerCase() === label);
        if (row) row.querySelector('strong').textContent = value;
      };
      if (profile.name) document.querySelector('#screen-profile .p-name').textContent = profile.name;
      if (profile.email) setRow('email', profile.email);
      if (profile.phone) setRow('phone number', profile.phone);
      if (profile.address) setRow('farm address', profile.address);
      if (profile.acres) setRow('acres owned', profile.acres);
      if (profile.acresCult) setRow('acres cultivating', profile.acresCult);
      if (profile.crops) setRow('main crops', profile.crops);
      if (profile.exp) setRow('farming experience (years)', profile.exp);

      toast('Profile saved');
      // Go back to profile view
      document.getElementById('screen-profile-edit')?.classList.add('hidden');
      document.getElementById('screen-profile')?.classList.remove('hidden');
    });

    // Advisory wiring
    const stateToDistricts = {
      Punjab: ['Mansa', 'Ludhiana', 'Amritsar', 'Sangrur'],
      Karnataka: ['Bengaluru', 'Doddaballapur', 'Mysuru', 'Hubballi'],
      'Tamil Nadu': ['Chennai', 'Coimbatore', 'Madurai'],
      Telangana: ['Hyderabad', 'Warangal', 'Nizamabad'],
    };

    function showAdvisory(){
      document.getElementById('screen-dashboard')?.classList.add('hidden');
      document.getElementById('screen-advisory')?.classList.remove('hidden');
      // Prefill location line from stored place
      try {
        const place = localStorage.getItem('ai4agri_place');
        if (place) document.getElementById('adv-location').textContent = 'Location: ' + place;
      } catch {}
    }

    // Tab from dashboard
    document.querySelector('#screen-dashboard .tabbar .tab:nth-child(2)')?.addEventListener('click', showAdvisory);
    // Back from advisory
    document.getElementById('btn-adv-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-advisory')?.classList.add('hidden');
      document.getElementById('screen-dashboard')?.classList.remove('hidden');
    });

    // Populate districts when state changes
    document.getElementById('adv-state')?.addEventListener('change', (e)=>{
      const state = e.target.value;
      const dist = document.getElementById('adv-district');
      dist.innerHTML = '<option value="" selected>Select District</option>' +
        (stateToDistricts[state]||[]).map(d=>`<option>${d}</option>`).join('');
    });

    // Buttons
    document.getElementById('btn-adv-details')?.addEventListener('click', ()=>{
      toast('Weather details fetched');
    });
    document.getElementById('btn-adv-reco')?.addEventListener('click', ()=>{
      const crop = document.getElementById('adv-crop').value || '—';
      document.getElementById('adv-res-crop').textContent = crop;
      // Example simple rules for demo; these can be replaced with API-driven data
      const rule = {
        Wheat: { plant:'Nov 1 – Dec 15', seed:'100–125 kg/ha', irr:'Irrigate at CRI, tillering, booting and milking', yield:'40–50 q/ha' },
        Rice:  { plant:'15 June – 15 July', seed:'25–30 kg/ha', irr:'450–700 mm. Keep field moist, irrigate at critical stages.', yield:'45–55 q/ha' },
        Maize: { plant:'Jun – Jul', seed:'18–20 kg/ha', irr:'Irrigate at tasseling and grain filling', yield:'30–40 q/ha' },
        Cotton:{ plant:'Apr – May', seed:'2.5–3.5 kg/ha', irr:'Irrigate based on soil moisture; avoid waterlogging', yield:'20–25 q/ha' },
      }[crop] || { plant:'—', seed:'—', irr:'—', yield:'—' };
      document.getElementById('adv-res-planting').textContent = rule.plant;
      document.getElementById('adv-res-seed').textContent = rule.seed;
      document.getElementById('adv-res-irrigation').textContent = rule.irr;
      document.getElementById('adv-res-yield').textContent = rule.yield;

      document.getElementById('adv-results')?.classList.remove('hidden');
      toast('Recommendations ready');
    });

    // Detection wiring
    function showDetection(){
      document.getElementById('screen-dashboard')?.classList.add('hidden');
      document.getElementById('screen-detection')?.classList.remove('hidden');
    }
    document.querySelector('#screen-dashboard .tabbar .tab:nth-child(3)')?.addEventListener('click', showDetection);
    // From Quick Actions: 1st button is Pest/disease Detection
    (function(){
      const qs = document.querySelectorAll('#screen-dashboard .quick-grid .quick');
      if (qs && qs.length >= 1) qs[0].addEventListener('click', showDetection);
    })();
    document.getElementById('btn-det-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-detection')?.classList.add('hidden');
      document.getElementById('screen-dashboard')?.classList.remove('hidden');
    });

    const drop = document.getElementById('det-drop');
    const input = document.getElementById('det-upload');
    const preview = document.getElementById('det-preview');
    const openPicker = ()=> input?.click();
    drop?.addEventListener('click', openPicker);
    drop?.addEventListener('keypress', (e)=>{ if(e.key==='Enter' || e.key===' '){ e.preventDefault(); openPicker(); }});
    input?.addEventListener('change', ()=>{
      const file = input.files?.[0];
      if (!file) return;
      if (file.size > 10*1024*1024) { toast('File too large'); return; }
      const url = URL.createObjectURL(file);
      preview.src = url; preview.classList.remove('hidden');
      drop.querySelector('.dz-in')?.classList.add('hidden');
    });
    document.getElementById('btn-det-analyze')?.addEventListener('click', ()=>{
      if (preview?.src) {
        toast('Analyzing image...');
        // After 2s, navigate to result screen and fill placeholders
        setTimeout(()=>{
          // carry over image
          const img = document.getElementById('detres-image');
          if (img) img.src = preview.src;
          // Example fixed result; can be replaced with model output
          document.getElementById('detres-name').textContent = 'Late blight';
          document.getElementById('detres-desc').textContent = 'Late blight, caused by the oomycete Phytophthora infestans, is a devastating disease of potatoes and tomatoes. It thrives in cool, moist conditions and can wipe out entire crops if left untreated.';

          document.getElementById('screen-detection')?.classList.add('hidden');
          document.getElementById('screen-detect-result')?.classList.remove('hidden');
        }, 2000);
      } else {
        toast('Please upload an image first');
      }
    });

    // Result nav
    document.getElementById('btn-detres-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-detect-result')?.classList.add('hidden');
      document.getElementById('screen-detection')?.classList.remove('hidden');
    });
    document.getElementById('btn-detres-scan')?.addEventListener('click', ()=>{
      document.getElementById('screen-detect-result')?.classList.add('hidden');
      document.getElementById('screen-detection')?.classList.remove('hidden');
    });

    // Soil Health wiring
    function showSoil(){
      document.getElementById('screen-dashboard')?.classList.add('hidden');
      document.getElementById('screen-soil')?.classList.remove('hidden');
    }
    // From quick action button on dashboard
    document.querySelector('#screen-dashboard .quick:nth-child(4)')?.addEventListener('click', showSoil);
    // Back
    document.getElementById('btn-soil-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-soil')?.classList.add('hidden');
      document.getElementById('screen-dashboard')?.classList.remove('hidden');
    });
    // Tabs demo
    const tabManual = document.getElementById('tab-manual');
    const tabSensor = document.getElementById('tab-sensor');
    function setTab(sensor){
      tabManual?.classList.toggle('active', !sensor);
      tabSensor?.classList.toggle('active', !!sensor);
      const manualBlk = document.getElementById('soil-manual');
      if (manualBlk) manualBlk.style.display = sensor ? 'none' : 'block';
    }
    tabManual?.addEventListener('click', ()=> setTab(false));
    tabSensor?.addEventListener('click', ()=> setTab(true));
    // Sensor connect demo
    document.getElementById('btn-scan-sensor')?.addEventListener('click', ()=>{
      const st = document.getElementById('sensor-status');
      st.textContent = 'Connecting…';
      setTimeout(()=>{ st.textContent = 'Connected';
        // Update metrics on connect demo
        document.getElementById('soil-overall').textContent = 'Moderate';
        document.getElementById('soil-progress').style.width = '65%';
        // Slightly tweak NPK polygon
        const poly = document.getElementById('npk-shape');
        if (poly) poly.setAttribute('points', '80,22 135,65 110,118 58,112 28,66');
      }, 900);
    });

    // Manual sliders logic
    const el = (id)=> document.getElementById(id);
    const labels = {
      ph: el('v-ph'), moist: el('v-moist'), n: el('v-n'), p: el('v-p'), k: el('v-k'), org: el('v-org'), micro: el('v-micro'),
    };
    const sliders = {
      ph: el('sl-ph'), moist: el('sl-moist'), n: el('sl-n'), p: el('sl-p'), k: el('sl-k'), org: el('sl-org'), micro: el('sl-micro'),
    };
    function updateLabels(){
      if (labels.ph && sliders.ph) labels.ph.textContent = Number(sliders.ph.value).toFixed(1);
      if (labels.moist && sliders.moist) labels.moist.textContent = sliders.moist.value + '%';
      ['n','p','k','org','micro'].forEach(key=>{ if(labels[key]&&sliders[key]) labels[key].textContent = sliders[key].value + '%'; });
    }
    function computeOverall(){
      // Simple average-based scoring demo (0-100)
      const vals = ['n','p','k','org','micro'].map(k=> Number(sliders[k]?.value||0));
      const moisture = Number(sliders.moist?.value||0);
      // Weight macros 70%, moisture 30%
      const macroAvg = vals.reduce((a,b)=>a+b,0)/vals.length;
      const score = Math.round(0.7*macroAvg + 0.3*moisture);
      const badge = el('soil-overall');
      const bar = el('soil-progress');
      if (bar) bar.style.width = Math.max(5, Math.min(100, score)) + '%';
      if (badge){
        badge.textContent = score >= 70 ? 'Good' : score >= 40 ? 'Moderate' : 'Low';
      }
      // Update radar polygon (rough mapping)
      const poly = el('npk-shape');
      if (poly){
        const pct = (v)=> Math.max(0, Math.min(1, v/100));
        const N = pct(Number(sliders.n?.value||0)), P = pct(Number(sliders.p?.value||0)), K = pct(Number(sliders.k?.value||0));
        const Mi = pct(Number(sliders.micro?.value||0));
        const Org = pct(Number(sliders.org?.value||0));
        // Base polygon radii offsets mapped into the star points
        const pts = [
          [80, 30 - 20*(N-0.5)],   // top N
          [130 + 10*(P-0.5), 65],  // right P
          [105, 120 + 10*(K-0.5)], // bottom-right K
          [55, 115 + 10*(Mi-0.5)], // bottom-left Micros
          [30 - 10*(Org-0.5), 65], // left Organic
        ];
        poly.setAttribute('points', pts.map(p=> p.join(',')).join(' '));
      }
    }
    function onManualChanged(){ updateLabels(); computeOverall(); }
    Object.values(sliders).forEach(s=> s?.addEventListener('input', onManualChanged));
    // Initialize
    updateLabels(); computeOverall(); setTab(false);

    // Weather screen wiring
    function showWeather(){
      document.getElementById('screen-dashboard')?.classList.add('hidden');
      document.getElementById('screen-weather')?.classList.remove('hidden');
      try {
        const place = localStorage.getItem('ai4agri_place');
        if (place) document.getElementById('w-loc').textContent = place;
      } catch {}
      // If API key is set and place is known, fetch real data
      const placeNow = document.getElementById('w-loc')?.textContent?.trim();
      if (placeNow){
        if (getWeatherApiKey()) {
          fetchAndRenderWeather(placeNow).catch(()=>{});
        } else {
          fetchAndRenderWeatherOM(placeNow).catch(()=>{});
        }
      }
    }
    // Click on the weather card in dashboard
    document.querySelector('#screen-dashboard .card.weather')?.addEventListener('click', showWeather);
    document.getElementById('btn-weather-back')?.addEventListener('click', ()=>{
      document.getElementById('screen-weather')?.classList.add('hidden');
      document.getElementById('screen-dashboard')?.classList.remove('hidden');
    });
    // Simple mock search
    document.getElementById('btn-weather-search')?.addEventListener('click', ()=>{
      const q = (document.getElementById('weather-search')?.value||'').trim();
      if (!q) return toast('Enter a location');
      document.getElementById('w-loc').textContent = q;
      if (getWeatherApiKey()) {
        fetchAndRenderWeather(q).catch((e)=>{ console.warn(e); toast('Failed to fetch weather'); });
      } else {
        // Use Open-Meteo (no API key required)
        fetchAndRenderWeatherOM(q).catch((e)=>{ console.warn(e); toast('Failed to fetch weather'); });
      }
    });

    // ============ OpenWeather integration ============
    function getWeatherApiKey(){
      try { return localStorage.getItem('owm_key') || window.OWM_API_KEY || ''; } catch { return ''; }
    }
    window.setWeatherApiKey = function(key){
      try { localStorage.setItem('owm_key', key); toast('Weather API key saved'); } catch {}
    };

    async function fetchJson(url){
      const res = await fetch(url);
      if (!res.ok) throw new Error('HTTP '+res.status);
      return res.json();
    }

    async function geocodePlace(place){
      const key = getWeatherApiKey();
      const url = `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(place)}&limit=1&appid=${key}`;
      const arr = await fetchJson(url);
      if (!arr || !arr.length) throw new Error('Place not found');
      return { lat: arr[0].lat, lon: arr[0].lon, name: arr[0].name };
    }

    function updateWeatherUI(current, place, alerts){
      document.getElementById('w-loc').textContent = place;
      document.getElementById('w-temp').textContent = Math.round(current.main.temp) + '°C';
      document.getElementById('w-cond').textContent = (current.weather?.[0]?.description||'').replace(/\b\w/g, c=> c.toUpperCase());
      document.getElementById('w-hum').textContent = (current.main.humidity ?? '-') + '%';
      document.getElementById('w-wind').textContent = Math.round(current.wind.speed) + ' km/h';
      const list = document.getElementById('w-alerts');
      list.innerHTML = '';
      (alerts && alerts.length ? alerts : synthesizeAlerts(current)).forEach(msg=>{
        const li = document.createElement('li'); li.className='alert'; li.textContent = msg; list.appendChild(li);
      });
    }

    function synthesizeAlerts(current){
      const out = [];
      const wmain = current.weather?.[0]?.main || '';
      const temp = current.main?.temp ?? 0;
      const wind = current.wind?.speed ?? 0;
      if (/Thunderstorm|Rain|Drizzle/i.test(wmain)) out.push('Heavy rainfall expected, carry protection for crops.');
      if (wind > 10) out.push('Strong winds expected; secure loose materials.');
      if (temp >= 38) out.push('Heat alert: ensure adequate irrigation.');
      if (!out.length) out.push('No significant alerts at this time.');
      return out;
    }

    async function fetchAndRenderWeather(place){
      const key = getWeatherApiKey();
      if (!key) throw new Error('Missing API key');
      const { lat, lon, name } = await geocodePlace(place);
      const currentUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${key}`;
      const current = await fetchJson(currentUrl);
      // Note: One Call 3.0 alerts require a subscription; we synthesize alerts when unavailable
      updateWeatherUI(current, name || place, []);
    }

    // -------- Open-Meteo fallback (no API key required) --------
    async function geocodeOM(place){
      const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(place)}&count=1&language=en&format=json`;
      const data = await fetchJson(url);
      if (!data || !data.results || !data.results.length) throw new Error('Place not found');
      const r = data.results[0];
      return { lat: r.latitude, lon: r.longitude, name: r.name };
    }
    async function fetchAndRenderWeatherOM(place){
      const { lat, lon, name } = await geocodeOM(place);
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m&timezone=auto`;
      const data = await fetchJson(url);
      const current = {
        main: { temp: data.current?.temperature_2m ?? 0, humidity: data.current?.relative_humidity_2m ?? 0 },
        wind: { speed: data.current?.wind_speed_10m ?? 0 },
        weather: [{ description: 'Scattered clouds' }],
      };
      updateWeatherUI(current, name || place, synthesizeAlerts(current));
    }
  });
})();
